package ejercicio1;

public class LeerTodo {

}
